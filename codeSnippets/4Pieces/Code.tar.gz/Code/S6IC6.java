
public class S6IC6 
{
	public static boolean compareArray(int a[], int b[]) 
	{
		boolean compare = false;
		if(a.equals(b) == b.equals(a))	
			compare = true;
		return compare;
	}
}
