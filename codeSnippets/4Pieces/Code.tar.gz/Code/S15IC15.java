
public class S15IC15 
{
	static String findCountry(int prefix) 
	{		
		switch(prefix) {
		case 1:     return "North America";
		case 44:    return "Great Britain";
		case 45:    return "Denmark";
		case 299:   return "Greenland";
		case 46:   return "Sweden";
		case 7:    return "Russia";
		case 972:     return "Israel";
		}
	}
}
