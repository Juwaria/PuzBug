
public class TestS14IC14 {

	public static void main(String[] args) {
		S14IC14 Test = new S14IC14();
		System.out.println(Test.validmonth(2,30));
        System.out.println(Test.leapyear(2004));

	}

}
