
public class TestS3IC3 {

	public static void main(String[] args) {
		
		int numbers[] = new int[]{32,43,53,54,32,65,63,98,43,23};
		S3IC3.LargestAndSmallest(numbers);

	}

}
