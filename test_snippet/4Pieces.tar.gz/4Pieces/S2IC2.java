
public class S2IC2 
{
	float p;	
	public static double Perimeter(double length, double breadth) 
	{
		p = 2*length+breadth;	
		return p;
	}
}
