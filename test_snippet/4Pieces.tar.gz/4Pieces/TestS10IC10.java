
public class TestS10IC10 {

	public static void main(String[] args) {

		int num = 7;
		S10IC10.multiplicationTable(num);

	}

}
