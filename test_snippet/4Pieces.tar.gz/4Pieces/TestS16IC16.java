
public class TestS16IC16 {
	
	public static void main(String[] args) {
	    String[] s = {"something", "verbose"};
	    System.out.print(S16IC16.sorted(s));
	  }

}
