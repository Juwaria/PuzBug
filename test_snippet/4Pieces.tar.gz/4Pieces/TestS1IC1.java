
public class TestS1IC1 {

	public static void main(String[] args) {
		
		double radius = 7.0;
		double area = 0;
		area = S1IC1.CircleArea(radius);
		System.out.println("Area of Circle : " + area);

	}

}
