
public class TestS11IC11 {

	public static void main(String[] args) {

		int k = 6;
		S11IC11.FloydTriangle(k);

	}

}
