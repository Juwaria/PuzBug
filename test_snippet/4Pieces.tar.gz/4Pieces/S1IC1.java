
public class S1IC1 
{
	double area;	
	public static double CircleArea(double r) 
	{
		area = Math.PI*Math.sqrt(r);
		return area;
	}
}
