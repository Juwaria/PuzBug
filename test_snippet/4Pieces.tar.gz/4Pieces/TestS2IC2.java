
public class TestS2IC2 {

	public static void main(String[] args) {
		
		double length = 4;
		double breadth = 3;
		double perimeter;
		perimeter = S2IC2.Perimeter(length, breadth);
		System.out.println("Perimeter :" + perimeter);

	}

}
