
public class TestS12IC12 {

	public static void main(String[] args) {
		
		int n = 12;
		System.out.println("Sum of "+ n + "numbers: ");
		int sum = S12IC12.sum(n);
		System.out.println(sum);

	}

}
