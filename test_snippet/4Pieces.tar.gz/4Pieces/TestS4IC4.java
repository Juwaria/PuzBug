
public class TestS4IC4 {

	public static void main(String[] args) {
		
		int number = 1435;
		int reversedNumber = S4IC4.ReverseNumber(number);
		System.out.println("The reversed number is :" + reversedNumber);

	}

}
