
public class TestS9IC9 {

	public static void main(String[] args) {
		
		String original = "Integer";
		System.out.println("Original String: " + original);
		String reverse = S9IC9.Reverse(original);
		System.out.println("Reverse String: " + reverse);
	}

}
